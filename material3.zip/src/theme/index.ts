export { ThemeModule } from './theme.module';
