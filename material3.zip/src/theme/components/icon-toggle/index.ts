export { IconToggleComponent } from './icon-toggle.component';
