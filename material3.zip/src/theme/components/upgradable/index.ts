export { UpgradableComponent } from './upgradable.component';
