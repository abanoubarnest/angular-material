export { SignUpComponent } from './sign-up.component';
