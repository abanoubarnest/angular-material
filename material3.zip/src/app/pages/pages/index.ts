export { PagesModule } from './pages.module';
