export class Book {
  color: string;
  iconName: string;
  id: number
  title: string;
  qnty: number;
  created_at: Date;
  updated_at: Date;

}
