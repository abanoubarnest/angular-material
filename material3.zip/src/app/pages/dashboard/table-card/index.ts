export { TableCardComponent } from './table-card.component';
