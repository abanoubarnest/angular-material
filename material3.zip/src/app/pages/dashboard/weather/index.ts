export { WeatherComponent } from './weather.component';
