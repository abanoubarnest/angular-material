export { BrowserStatisticsChartComponent } from './browser-statistics-chart.component';
export { BrowserStatisticsChartService } from './browser-statistics-chart.service';
